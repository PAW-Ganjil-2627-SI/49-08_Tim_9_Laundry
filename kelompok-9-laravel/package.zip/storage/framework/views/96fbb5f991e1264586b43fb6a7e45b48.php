<div class="form-group">
    <label>Nama</label>
    <input type="text" name="nama" value="<?php echo e(old('nama', $pelanggan->nama ?? '')); ?>">
</div>
<div class="form-group">
    <label>Alamat</label>
    <textarea name="alamat"><?php echo e(old('alamat', $pelanggan->alamat ?? '')); ?></textarea>
</div>
<div class="form-group">
    <label>No. Telepon</label>
    <input type="text" name="no_telepon" value="<?php echo e(old('no_telepon', $pelanggan->no_telepon ?? '')); ?>">
</div>
<div class="form-group">
    <label>Catatan Khusus Pakaian</label>
    <textarea name="catatan_khusus"><?php echo e(old('catatan_khusus', $pelanggan->catatan_khusus ?? '')); ?></textarea>
</div><?php /**PATH C:\Users\KAILA SILVA\progrm\week10\Semester 3\Pengembangan Web\Kelompok-9\kelompok-9-laravel\resources\views/pelanggan/_form.blade.php ENDPATH**/ ?>