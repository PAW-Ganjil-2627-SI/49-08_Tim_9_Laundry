<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Data Pelanggan'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
<header class="site-header">
    <div class="header-inner">
        <h1>Data Pelanggan</h1>
        <p>Biodata pelanggan dan catatan penanganan khusus pakaian</p>
    </div>
</header>
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
</body>
</html><?php /**PATH C:\Users\KAILA SILVA\progrm\week10\Semester 3\Pengembangan Web\Kelompok-9\kelompok-9-laravel\resources\views/pelanggan/layout.blade.php ENDPATH**/ ?>