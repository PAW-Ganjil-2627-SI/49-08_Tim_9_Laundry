
<?php $__env->startSection('title', 'Tambah Pelanggan'); ?>
<?php $__env->startSection('content'); ?>

<div class="toolbar"><h2>Tambah Pelanggan</h2></div>

<?php if($errors->any()): ?>
    <div class="alert alert-error">
        <ul style="margin:0; padding-left:20px;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($e); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card" style="padding:24px; max-width:560px;">
    <form action="<?php echo e(route('pelanggan.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('pelanggan._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <button class="btn btn-primary">Simpan</button>
        <a href="<?php echo e(route('pelanggan.index')); ?>" class="btn">Batal</a>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pelanggan.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\KAILA SILVA\progrm\week10\Semester 3\Pengembangan Web\Kelompok-9\kelompok-9-laravel\resources\views/pelanggan/create.blade.php ENDPATH**/ ?>